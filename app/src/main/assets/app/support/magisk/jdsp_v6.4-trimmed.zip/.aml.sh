API="$(getprop ro.build.version.sdk)"
[ "$API" -ge 26 ] && libdir="/vendor" || libdir="/system"

AIDLCHECK=$(find /vendor/lib64/soundfx /odm/lib64/soundfx /system/lib64/soundfx -type f -name *aidl.so)
if [ ! -z "$AIDLCHECK" ]; then
	AIDL=true
else
	AIDL=false
fi

LIB=libjamesdsp.so
LIBNAME=jdsp
NAME=jamesdsp
UUID=f27317f4-c984-4de6-9a90-545759495bf2
TYPE=f98765f4-c321-5de6-9a45-123459495ab2
AUDEFCONF="$(find $MODPATH -type f -name *audio*effects*.conf)"
AUDEFXML="$(find $MODPATH -type f -name *audio*effects*.xml)"

if [ $AIDL == "true" ]; then
	for XML in $AUDEFXML; do
	  sed -i "/<libraries>/a\        <library name=\"$LIBNAME\" path=\"$LIB\"\/>" $XML
	  sed -i "/<effects>/a\        <effect name=\"$NAME\" library=\"$LIBNAME\" uuid=\"$UUID\"\ type=\"$TYPE\"\/>" $XML
	done
else
	for CONF in $AUDEFCONF; do
	  sed -i "/^libraries {/a\  $LIBNAME {\n    path \\$libdir\/lib\/soundfx\/$LIB\n  }" $CONF
	  sed -i "/^effects {/a\  $NAME {\n    library $LIBNAME\n    uuid $UUID\n  }" $CONF
	done

	for XML in $AUDEFXML; do
	  sed -i "/<libraries>/a\        <library name=\"$LIBNAME\" path=\"$LIB\"\/>" $XML
	  sed -i "/<effects>/a\        <effect name=\"$NAME\" library=\"$LIBNAME\" uuid=\"$UUID\"\/>" $XML
	done
fi