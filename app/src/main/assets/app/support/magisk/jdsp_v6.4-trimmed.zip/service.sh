#!/system/bin/sh
(
AUD=$(find $MODDIR -type f -name "*audio_effects*.conf" -o -name "*audio_effects*.xml")
if [ ! -z "$AUD" ];then
for i in $AUD; do
  j="$(echo $i | sed "s|$MODDIR/system||")"
  mount -o bind $i $j
done
killall -q audioserver
fi
)&

counter=0
while [ $(getprop ro.audio.ignore_effects) == 'true' ] || [ $counter -le 20 ]; do
resetprop ro.audio.ignore_effects false
sleep 1
counter=$(($counter+1))
done &
